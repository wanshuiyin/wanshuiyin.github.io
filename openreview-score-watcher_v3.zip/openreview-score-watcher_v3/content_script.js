// content_script.js

(function () {
  const STORAGE_WATCH_LIST = "openreview_watch_list";

  const isOpenReviewForum =
    window.location.hostname === "openreview.net" &&
    window.location.pathname === "/forum";

  // ------------- 工具 -------------

  function getForumIdFromUrl() {
    try {
      const url = new URL(window.location.href);
      return url.searchParams.get("id") || "";
    } catch (e) {
      return "";
    }
  }

  function upsertWatchList(list, item) {
    const maxLen = 30; // 最多记 30 篇
    const newList = Array.isArray(list) ? [...list] : [];
    const idx = newList.findIndex((x) => x.forumId === item.forumId);

    if (idx >= 0) {
      newList[idx] = { ...newList[idx], ...item };
    } else {
      newList.push(item);
    }

    // 超长则丢掉最旧的
    if (newList.length > maxLen) {
      newList.sort(
        (a, b) =>
          (a.data && a.data.lastUpdated ? a.data.lastUpdated : 0) -
          (b.data && b.data.lastUpdated ? b.data.lastUpdated : 0)
      );
      while (newList.length > maxLen) {
        newList.shift();
      }
    }

    return newList;
  }

  // ------------- 浮窗 UI -------------

  let panelEl = null;

  function ensurePanel() {
    if (panelEl) return panelEl;

    panelEl = document.createElement("div");
    panelEl.id = "or-score-watcher-panel";
    panelEl.style.position = "fixed";
    panelEl.style.bottom = "16px";
    panelEl.style.right = "16px";
    panelEl.style.zIndex = "999999";
    panelEl.style.background = "rgba(0,0,0,0.85)";
    panelEl.style.color = "#fff";
    panelEl.style.fontSize = "12px";
    panelEl.style.padding = "10px 14px";
    panelEl.style.borderRadius = "8px";
    panelEl.style.maxWidth = "340px";
    panelEl.style.lineHeight = "1.4";
    panelEl.style.boxShadow = "0 2px 6px rgba(0,0,0,0.3)";
    panelEl.style.cursor = "default";
    panelEl.style.fontFamily =
      "system-ui, -apple-system, BlinkMacSystemFont, sans-serif";

    const contextLabel = isOpenReviewForum ? "（本页会自动加入监控）" : "";

    panelEl.innerHTML = `
      <div style="font-weight:bold;margin-bottom:4px;">
        OpenReview 分数监控 ${contextLabel}
      </div>
      <div id="or-score-watcher-content">
        正在读取监控列表…
      </div>
      <div id="or-score-watcher-footer" style="margin-top:4px;opacity:0.7;">
      </div>
    `;

    document.body.appendChild(panelEl);
    return panelEl;
  }

  function updatePanel(watchList, currentForumId) {
    const panel = ensurePanel();
    const contentEl = panel.querySelector("#or-score-watcher-content");
    const footerEl = panel.querySelector("#or-score-watcher-footer");
    if (!contentEl || !footerEl) return;

    if (!watchList || watchList.length === 0) {
      contentEl.textContent = "当前没有监控中的 OpenReview 论文。";
      footerEl.textContent =
        "打开任意 OpenReview 论文页即可自动加入监控。";
      return;
    }

    const sorted = [...watchList].sort(
      (a, b) =>
        (b.data && b.data.lastUpdated ? b.data.lastUpdated : 0) -
        (a.data && a.data.lastUpdated ? a.data.lastUpdated : 0)
    );

    const topN = sorted.slice(0, 5);
    const lines = topN.map((item) => {
      const scores = (item.data && item.data.scores) || [];
      const avg =
        item.data && item.data.average != null
          ? item.data.average.toFixed(2)
          : "N/A";
      const timeStr =
        item.data && item.data.lastUpdated
          ? new Date(item.data.lastUpdated).toLocaleTimeString()
          : "-";
      const shortId = item.forumId || "(unknown)";
      const rawTitle = item.title || "(no title)";
      const shortTitle =
        rawTitle.length > 40 ? rawTitle.slice(0, 40) + "..." : rawTitle;

      const isCurrent = currentForumId && currentForumId === item.forumId;

      return `
        <div style="margin-bottom:4px;${isCurrent ? "border-left:2px solid #4ade80;padding-left:6px;" : ""}">
          <div style="font-weight:600;">${shortTitle}</div>
          <div style="opacity:0.9;">ID: ${shortId}</div>
          <div>评分: [${
            scores.length ? scores.join(", ") : "暂无"
          }], 均值: ${avg}</div>
          <div style="opacity:0.7;">更新于: ${timeStr}</div>
        </div>
      `;
    });

    contentEl.innerHTML = lines.join(
      "<hr style='border:none;border-top:1px solid rgba(255,255,255,0.15);margin:4px 0;' />"
    );
    footerEl.textContent = `正在监控 ${watchList.length} 篇论文（显示最近 ${topN.length} 篇）。`;
  }

  // ------------- 主逻辑 -------------

  ensurePanel();

  const currentForumId = isOpenReviewForum ? getForumIdFromUrl() : "";

  // 在 OpenReview 论文页：自动把当前论文加入监控列表
  if (isOpenReviewForum && currentForumId) {
    const title = document.title || "";

    chrome.storage.local.get([STORAGE_WATCH_LIST], (result) => {
      const oldList = result[STORAGE_WATCH_LIST] || [];
      const newList = upsertWatchList(oldList, {
        forumId: currentForumId,
        url: window.location.href,
        title,
        // data 留给 background.js 填
        data: oldList.find((x) => x.forumId === currentForumId)?.data || {
          scores: [],
          average: null,
          lastUpdated: null
        }
      });

      chrome.storage.local.set(
        {
          [STORAGE_WATCH_LIST]: newList
        },
        () => {
          updatePanel(newList, currentForumId);
        }
      );
    });
  } else {
    // 非 OpenReview 页面：只展示当前监控列表
    chrome.storage.local.get([STORAGE_WATCH_LIST], (result) => {
      const watchList = result[STORAGE_WATCH_LIST] || [];
      updatePanel(watchList, currentForumId);
    });
  }

  // 所有页面都监听 watch list 变化 → 实时刷新 UI
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[STORAGE_WATCH_LIST]) {
      const newList = changes[STORAGE_WATCH_LIST].newValue || [];
      updatePanel(newList, currentForumId);
    }
  });
})();

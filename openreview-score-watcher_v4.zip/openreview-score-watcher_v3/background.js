// background.js

const STORAGE_WATCH_LIST = "openreview_watch_list";
const POLL_INTERVAL_MINUTES = 0.5; // 每 1 分钟轮询一次（Chrome alarms 最小 1 分钟）

// 安装 / 浏览器启动 时，确保闹钟存在
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("openreview-poll", {
    periodInMinutes: POLL_INTERVAL_MINUTES
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("openreview-poll", {
    periodInMinutes: POLL_INTERVAL_MINUTES
  });
});

// 构造通知里的文案
function buildMessage(item, oldData, newData) {
  const oldScores = (oldData && oldData.scores) || [];
  const newScores = (newData && newData.scores) || [];

  const oldAvg =
    oldData && oldData.average != null
      ? oldData.average.toFixed(2)
      : "N/A";
  const newAvg =
    newData && newData.average != null
      ? newData.average.toFixed(2)
      : "N/A";

  const title =
    item.title && item.title.length > 60
      ? item.title.slice(0, 60) + "..."
      : item.title || item.forumId;

  return {
    title: "OpenReview 分数更新",
    message:
      `${title}\n` +
      `ID: ${item.forumId}\n` +
      `旧评分: [${oldScores.join(", ")}], 平均: ${oldAvg}\n` +
      `新评分: [${newScores.join(", ")}], 平均: ${newAvg}`
  };
}

const API_BASE = "https://api2.openreview.net";

// 用 OpenReview API 拉取某篇论文所有评审的 rating
async function fetchScoresForForum(forumId) {
  const url = `https://api2.openreview.net/notes?count=true&details=writable,signatures,invitation,presentation,tags&domain=ICLR.cc/2026/Conference&forum=${forumId}&limit=1000&trash=true`;

  console.log("[ScoreWatcher] Fetching reviews via:", url);

  const res = await fetch(url, {
    method: "GET",
    credentials: "include",
    headers: {
      "accept": "application/json,text/*;q=0.99"
    }
  });

  if (!res.ok) {
    throw new Error("HTTP " + res.status);
  }

  const data = await res.json();

  if (!data.notes || !Array.isArray(data.notes)) {
    console.log("[ScoreWatcher] Unexpected response structure");
    return { scores: [], average: null, lastUpdated: Date.now() };
  }

  const scores = [];

  for (const note of data.notes) {
    const content = note.content || {};

    // ---- 1. 找 rating 字段 ----
    let ratingValue = null;

    if (content.rating !== undefined) {
      ratingValue = content.rating;
    } else {
      for (const [k, v] of Object.entries(content)) {
        const key = k.toLowerCase();
        if (
          key.includes("rating") ||
          key.includes("recommendation")
        ) {
          ratingValue = v;
          break;
        }
      }
    }

    if (!ratingValue) continue;

    // ---- 2. rating 可能是 object/string ----
    let ratingStr = "";
    if (typeof ratingValue === "object" && ratingValue.value !== undefined) {
      ratingStr = String(ratingValue.value);
    } else {
      ratingStr = String(ratingValue);
    }

    // ---- 3. 抽取纯数字评分 ----
    const match = ratingStr.match(/([0-9]+(?:\.[0-9]+)?)/);
    if (!match) continue;

    const score = Number(match[1]);
    if (!isNaN(score)) {
      scores.push(score);
    }
  }

  // ---- 4. 计算平均分 ----
  let average = null;
  if (scores.length > 0) {
    average = scores.reduce((a, b) => a + b, 0) / scores.length;
  }

  const result = {
    scores,
    average,
    lastUpdated: Date.now()
  };

  console.log("[ScoreWatcher] Parsed scores:", result);

  return result;
}

// 真正执行轮询的逻辑
async function handlePollAlarm() {
  chrome.storage.local.get([STORAGE_WATCH_LIST], async (result) => {
    const list = result[STORAGE_WATCH_LIST] || [];
    if (!Array.isArray(list) || list.length === 0) return;

    const updatedList = [...list];

    for (let i = 0; i < list.length; i++) {
      const item = list[i];
      if (!item.forumId) continue;

      try {
        const newData = await fetchScoresForForum(item.forumId);
        const oldData = item.data || null;

        const oldKey = oldData
          ? JSON.stringify(oldData.scores || [])
          : "";
        const newKey = JSON.stringify(newData.scores || []);

        const isChanged = oldKey !== newKey;

        updatedList[i] = { ...item, data: newData };

        if (isChanged) {
          const { title, message } = buildMessage(
            item,
            oldData,
            newData
          );

          chrome.notifications.create({
            type: "basic",
            iconUrl: chrome.runtime.getURL("icon128.png"),
            title,
            message
          });
        }
      } catch (err) {
        console.error(
          "[OpenReview Score Watcher] fetch error for",
          item.forumId,
          err
        );
      }
    }

    chrome.storage.local.set({
      [STORAGE_WATCH_LIST]: updatedList
    });
  });
}

// 监听闹钟
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "openreview-poll") {
    handlePollAlarm();
  }
});

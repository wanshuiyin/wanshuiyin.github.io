// content_script.js

(function () {
  const STORAGE_WATCH_LIST = "openreview_watch_list";
  const STORAGE_PANEL_STATE = "openreview_panel_state";

  const isOpenReviewForum =
    window.location.hostname === "openreview.net" &&
    window.location.pathname === "/forum";

  // ------------- 工具 -------------

  function getForumIdFromUrl() {
    try {
      const url = new URL(window.location.href);
      return url.searchParams.get("id") || "";
    } catch (e) {
      return "";
    }
  }

  function upsertWatchList(list, item) {
    const maxLen = 30; // 最多记 30 篇
    const newList = Array.isArray(list) ? [...list] : [];
    const idx = newList.findIndex((x) => x.forumId === item.forumId);

    if (idx >= 0) {
      newList[idx] = { ...newList[idx], ...item };
    } else {
      newList.push(item);
    }

    // 超长则丢掉最旧的
    if (newList.length > maxLen) {
      newList.sort(
        (a, b) =>
          (a.data && a.data.lastUpdated ? a.data.lastUpdated : 0) -
          (b.data && b.data.lastUpdated ? b.data.lastUpdated : 0)
      );
      while (newList.length > maxLen) {
        newList.shift();
      }
    }

    return newList;
  }

  // ------------- 浮窗 UI（可拖动 + 收起 + 记忆） -------------

  let panelEl = null;
  let isCollapsed = false;
  let dragState = null; // { startX, startY, startLeft, startTop }

  function applyCollapseState(panel) {
    const bodyEl = panel.querySelector("#or-score-watcher-body");
    const toggleBtn = panel.querySelector("#or-score-watcher-toggle");
    if (!bodyEl || !toggleBtn) return;

    if (isCollapsed) {
      bodyEl.style.display = "none";
      panel.style.maxWidth = "200px";
      panel.style.width = "auto";
      toggleBtn.textContent = "展开";
    } else {
      bodyEl.style.display = "block";
      panel.style.maxWidth = "340px";
      toggleBtn.textContent = "收起";
    }
  }

  function savePanelState(extra) {
    // extra: { left, top, isCollapsed }
    chrome.storage.local.get([STORAGE_PANEL_STATE], (result) => {
      const prev = result[STORAGE_PANEL_STATE] || {};
      const next = {
        ...prev,
        ...extra
      };
      chrome.storage.local.set({ [STORAGE_PANEL_STATE]: next });
    });
  }

  function ensurePanel() {
    if (panelEl) return panelEl;

    panelEl = document.createElement("div");
    panelEl.id = "or-score-watcher-panel";
    panelEl.style.position = "fixed";
    // 初始放右下角，后面会根据记忆状态调整
    panelEl.style.bottom = "16px";
    panelEl.style.right = "16px";
    panelEl.style.zIndex = "999999";
    panelEl.style.background = "rgba(0,0,0,0.85)";
    panelEl.style.color = "#fff";
    panelEl.style.fontSize = "12px";
    panelEl.style.padding = "0";
    panelEl.style.borderRadius = "8px";
    panelEl.style.maxWidth = "340px";
    panelEl.style.lineHeight = "1.4";
    panelEl.style.boxShadow = "0 2px 6px rgba(0,0,0,0.3)";
    panelEl.style.cursor = "default";
    panelEl.style.fontFamily =
      "system-ui, -apple-system, BlinkMacSystemFont, sans-serif";

    const contextLabel = isOpenReviewForum ? "（本页会自动加入监控）" : "";

    panelEl.innerHTML = `
      <div id="or-score-watcher-header"
           style="display:flex;align-items:center;justify-content:space-between;
                  padding:6px 8px;border-bottom:1px solid rgba(255,255,255,0.15);
                  cursor:move;">
        <div style="font-weight:bold;margin-right:8px;">
          OpenReview 分数监控 ${contextLabel}
        </div>
        <button id="or-score-watcher-toggle"
                style="border:none;outline:none;background:transparent;
                       color:#fff;cursor:pointer;font-size:12px;padding:2px 4px;">
          收起
        </button>
      </div>
      <div id="or-score-watcher-body"
           style="padding:8px 10px;">
        <div id="or-score-watcher-content">
          正在读取监控列表…
        </div>
        <div id="or-score-watcher-footer"
             style="margin-top:4px;opacity:0.7;">
        </div>
      </div>
    `;

    document.body.appendChild(panelEl);

    const toggleBtn = panelEl.querySelector("#or-score-watcher-toggle");
    const headerEl = panelEl.querySelector("#or-score-watcher-header");

    // ---------- 收起 / 展开 ----------
    toggleBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      isCollapsed = !isCollapsed;
      applyCollapseState(panelEl);
      savePanelState({ isCollapsed });
    });

    // ---------- 拖拽 ----------
    headerEl.addEventListener("mousedown", (e) => {
      if (e.button !== 0) return; // 只响应左键
      e.preventDefault();

      const rect = panelEl.getBoundingClientRect();

      // 拖动时统一采用 left/top，移除 right/bottom
      panelEl.style.left = rect.left + "px";
      panelEl.style.top = rect.top + "px";
      panelEl.style.right = "auto";
      panelEl.style.bottom = "auto";

      dragState = {
        startX: e.clientX,
        startY: e.clientY,
        startLeft: rect.left,
        startTop: rect.top
      };

      document.addEventListener("mousemove", onDragMove);
      document.addEventListener("mouseup", onDragEnd);
    });

    function onDragMove(e) {
      if (!dragState) return;
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;

      let newLeft = dragState.startLeft + dx;
      let newTop = dragState.startTop + dy;

      // 防止拖出屏幕
      const margin = 10;
      const ww = window.innerWidth;
      const wh = window.innerHeight;
      const rect = panelEl.getBoundingClientRect();
      const w = rect.width;
      const h = rect.height;

      if (newLeft < margin) newLeft = margin;
      if (newTop < margin) newTop = margin;
      if (newLeft + w > ww - margin) newLeft = ww - margin - w;
      if (newTop + h > wh - margin) newTop = wh - margin - h;

      panelEl.style.left = newLeft + "px";
      panelEl.style.top = newTop + "px";
    }

    function onDragEnd() {
      if (dragState) {
        const rect = panelEl.getBoundingClientRect();
        savePanelState({
          left: rect.left,
          top: rect.top
        });
      }
      dragState = null;
      document.removeEventListener("mousemove", onDragMove);
      document.removeEventListener("mouseup", onDragEnd);
    }

    // ---------- 读取记忆状态（位置 + 收起） ----------
    chrome.storage.local.get([STORAGE_PANEL_STATE], (result) => {
      const state = result[STORAGE_PANEL_STATE] || {};

      if (typeof state.isCollapsed === "boolean") {
        isCollapsed = state.isCollapsed;
      }

      if (
        typeof state.left === "number" &&
        typeof state.top === "number"
      ) {
        panelEl.style.left = state.left + "px";
        panelEl.style.top = state.top + "px";
        panelEl.style.right = "auto";
        panelEl.style.bottom = "auto";
      }

      applyCollapseState(panelEl);
    });

    // 初始也应用一次（防止 storage 还没回来时的状态闪烁）
    applyCollapseState(panelEl);

    return panelEl;
  }

  function updatePanel(watchList, currentForumId) {
    const panel = ensurePanel();
    const contentEl = panel.querySelector("#or-score-watcher-content");
    const footerEl = panel.querySelector("#or-score-watcher-footer");
    if (!contentEl || !footerEl) return;

    if (!watchList || watchList.length === 0) {
      contentEl.textContent = "当前没有监控中的 OpenReview 论文。";
      footerEl.textContent =
        "打开任意 OpenReview 论文页即可自动加入监控。";
      return;
    }

    const sorted = [...watchList].sort(
      (a, b) =>
        (b.data && b.data.lastUpdated ? b.data.lastUpdated : 0) -
        (a.data && a.data.lastUpdated ? a.data.lastUpdated : 0)
    );

    const topN = sorted.slice(0, 5);
    const lines = topN.map((item) => {
      const scores = (item.data && item.data.scores) || [];
      const avg =
        item.data && item.data.average != null
          ? item.data.average.toFixed(2)
          : "N/A";
      const timeStr =
        item.data && item.data.lastUpdated
          ? new Date(item.data.lastUpdated).toLocaleTimeString()
          : "-";
      const shortId = item.forumId || "(unknown)";
      const rawTitle = item.title || "(no title)";
      const shortTitle =
        rawTitle.length > 40 ? rawTitle.slice(0, 40) + "..." : rawTitle;

      const isCurrent = currentForumId && currentForumId === item.forumId;

      return `
        <div style="margin-bottom:4px;${isCurrent ? "border-left:2px solid #4ade80;padding-left:6px;" : ""}">
          <div style="font-weight:600;">${shortTitle}</div>
          <div style="opacity:0.9;">ID: ${shortId}</div>
          <div>评分: [${
            scores.length ? scores.join(", ") : "暂无"
          }], 均值: ${avg}</div>
          <div style="opacity:0.7;">更新于: ${timeStr}</div>
        </div>
      `;
    });

    contentEl.innerHTML = lines.join(
      "<hr style='border:none;border-top:1px solid rgba(255,255,255,0.15);margin:4px 0;' />"
    );
    footerEl.textContent = `正在监控 ${watchList.length} 篇论文（显示最近 ${topN.length} 篇）。`;
  }

  // ------------- 主逻辑 -------------

  ensurePanel();

  const currentForumId = isOpenReviewForum ? getForumIdFromUrl() : "";

  // 在 OpenReview 论文页：自动把当前论文加入监控列表
  if (isOpenReviewForum && currentForumId) {
    const title = document.title || "";

    chrome.storage.local.get([STORAGE_WATCH_LIST], (result) => {
      const oldList = result[STORAGE_WATCH_LIST] || [];
      const newList = upsertWatchList(oldList, {
        forumId: currentForumId,
        url: window.location.href,
        title,
        // data 留给 background.js 填
        data: oldList.find((x) => x.forumId === currentForumId)?.data || {
          scores: [],
          average: null,
          lastUpdated: null
        }
      });

      chrome.storage.local.set(
        {
          [STORAGE_WATCH_LIST]: newList
        },
        () => {
          updatePanel(newList, currentForumId);
        }
      );
    });
  } else {
    // 非 OpenReview 页面：只展示当前监控列表
    chrome.storage.local.get([STORAGE_WATCH_LIST], (result) => {
      const watchList = result[STORAGE_WATCH_LIST] || [];
      updatePanel(watchList, currentForumId);
    });
  }

  // 所有页面都监听 watch list 变化 → 实时刷新 UI
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[STORAGE_WATCH_LIST]) {
      const newList = changes[STORAGE_WATCH_LIST].newValue || [];
      updatePanel(newList, currentForumId);
    }
  });
})();
